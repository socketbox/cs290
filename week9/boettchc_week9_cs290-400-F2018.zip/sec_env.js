module.exports = {
    dev: {
        dbHost: "localhost",
        dbUser: "chb",
        dbPass: "endear-BLP3-threat-over-roughhew"
    },
    prod: {
        dbHost: "classmysql.engr.oregonstate.edu",
        dbUser: "cs290_boettchc",
        dbPass: "mount-W4PR-gullet-lake"
    }
};
