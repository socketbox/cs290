 module.exports = {
  cookieSecret: 'woman-hurray-H59L-jujitsu-rosary',
  sendgrid_api_key: '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'
 };
